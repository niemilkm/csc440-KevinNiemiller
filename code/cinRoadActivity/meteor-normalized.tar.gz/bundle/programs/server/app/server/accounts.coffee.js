(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.startup(function() {
  return AccountsEntry.config({
    signupCode: null
  });
});

})();

//# sourceMappingURL=accounts.coffee.js.map
