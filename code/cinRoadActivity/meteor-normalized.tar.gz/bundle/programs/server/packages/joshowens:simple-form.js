(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['joshowens:simple-form'] = {};

})();

//# sourceMappingURL=joshowens:simple-form.js.map
